import express from 'express';
import notes from './api/notes/routes.js';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = 3000;

app.use(express.json());
app.use('/', notes);

app.listen(port, () => {
  console.log(`server start at http://localhost:${port}`);
});